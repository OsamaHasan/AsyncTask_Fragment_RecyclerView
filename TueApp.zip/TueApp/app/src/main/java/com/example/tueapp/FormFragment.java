package com.example.tueapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;


public class FormFragment extends Fragment {

    private ImageView imageView;
    private TextView PhotoTaker;
    private Button Send, apiCall;
    private Fragment fragment;
    private EditText name, email;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_form, container, false);
        imageView = view.findViewById(R.id.photo);
        PhotoTaker = view.findViewById(R.id.takePhoto);
        Send = view.findViewById(R.id.send);
        apiCall = view.findViewById(R.id.apiCall);
        name = view.findViewById(R.id.name);
        email = view.findViewById(R.id.email);


        Send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fragment = new example(); //example is a fragment
                Bundle bundle = new Bundle();
                bundle.putString("name", name.getText().toString());
                bundle.putString("email", email.getText().toString());
                fragment.setArguments(bundle);
                FragmentManager fragmentManager = getFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragment_container, fragment);
                fragmentTransaction.commit();
            }
        });

        apiCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fragment = new RecyclerViewFragment(); //example is a fragment
                FragmentManager fragmentManager = getFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragment_container, fragment);
                fragmentTransaction.commit();
            }
        });

        PhotoTaker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, 0);
            }
        });



        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Bitmap image = (Bitmap) data.getExtras().get("data");
        imageView.setImageBitmap(image);
        PhotoTaker.setText("Retake Photo");
    }
}
