package com.example.tueapp;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class RecyclerViewFragment extends Fragment {

    private List<Post> posts;
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList<Post> arrayList;
    private ProgressBar progressBar1;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View view = inflater.inflate(R.layout.fragment_recycler_view, container, false);

        progressBar1 = view.findViewById(R.id.progressBar1);
        arrayList = new ArrayList<Post>();

        recyclerView = view.findViewById(R.id.recyclerView1);

        asyncTask task = new asyncTask();
        task.execute(0);

        return view;
    }

    private class asyncTask extends AsyncTask<Integer, Integer, String> {

        @Override
        protected String doInBackground(Integer... integers) {

            Retrofit retrofit = new Retrofit.Builder().baseUrl("https://jsonplaceholder.typicode.com/")
                    .addConverterFactory(GsonConverterFactory.create()).build();

            JsonPlaceholderApi jsonPlaceholderApi = retrofit.create(JsonPlaceholderApi.class);

            Call<List<Post>> call = jsonPlaceholderApi.getPosts();

            call.enqueue(new Callback<List<Post>>() {
                @Override
                public void onResponse(Call<List<Post>> call, Response<List<Post>> response) {
                    if (!response.isSuccessful()){
                        Toast.makeText(getActivity(), "Error: "+response.code(), Toast.LENGTH_LONG).show();
                        return;
                    }

                    posts = response.body();

                    for (Post post : posts){
                        publishProgress();
                        arrayList.add(new Post(post.getId(),post.getUserId(),post.getTitle(),post.getText()));
                    }

                }

                @Override
                public void onFailure(Call<List<Post>> call, Throwable t) {
                    Toast.makeText(getActivity(), "Error: "+t.getMessage(), Toast.LENGTH_LONG).show();
                }
            });


            return "";
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            progressBar1.setVisibility(View.INVISIBLE);

            layoutManager = new LinearLayoutManager(getActivity());

            adapter = new Adapter(arrayList);

            recyclerView.setLayoutManager(layoutManager);

            recyclerView.setAdapter(adapter);

        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);



        }
    }
}
