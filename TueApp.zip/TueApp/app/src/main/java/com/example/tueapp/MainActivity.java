package com.example.tueapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

        private ProgressBar progressBar;

        private TextView loadText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressBar = findViewById(R.id.progressBar);
        loadText = findViewById(R.id.loadText);

        asyncTask task = new asyncTask();
        task.execute(10);

    }

    private class asyncTask extends AsyncTask<Integer, Integer, String>{

        @Override
        protected String doInBackground(Integer... integers) {

            for (int i=0; i < integers[0]; i++){
                publishProgress(i*100/integers[0]);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            return "";
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            loadText.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.VISIBLE);

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            progressBar.setProgress(0);
            progressBar.setVisibility(View.INVISIBLE);
            loadText.setVisibility(View.INVISIBLE);
            Intent intent = new Intent(MainActivity.this, Form.class);
            startActivity(intent);
            finish();
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);

            progressBar.setProgress(values[0]);
        }
    }
}
